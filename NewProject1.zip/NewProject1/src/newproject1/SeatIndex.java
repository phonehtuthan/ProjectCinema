/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package newproject1;
import static java.awt.Color.green;
import static java.awt.Color.orange;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author northerncity
 */
public class SeatIndex extends javax.swing.JFrame {

    public DefaultTableModel model=new DefaultTableModel();
    public String cols[]={"id","no","type","price","status","theater_name"};
    
    public JPopupMenu mainMenu=new JPopupMenu();
    public JMenuItem editMenu=new JMenuItem("Edit");
    public JMenuItem deleteMenu=new JMenuItem("Delete");
    
    
    /**
     * Creates new form SeatIndex
     */
    public SeatIndex() {
        initComponents();
        loadSeats();
        
        model.setColumnIdentifiers(cols);
        
        try{
            Database Db=new Database();
            Connection conn=Db.getConnected();
            
            String sql="Select * from seat";
            
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            
            while(rs.next()){
                int id=rs.getInt("id");
                String no=rs.getString("no");
                String type=rs.getString("type");
                String price=rs.getString("price");
                String status=rs.getString("status");
                String theater_name=rs.getString("theater_name");
                
                model.addRow(new Object[]{id,no,type,price,status,theater_name});
            }
            
            jTable1.setModel(model);
            
            jTable1.setComponentPopupMenu(mainMenu);
            mainMenu.add(editMenu);
            mainMenu.add(deleteMenu);
            
            deleteMenu.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    int row=jTable1.getSelectedRow();
                    int col=0;
                  
                    int id=(int) jTable1.getValueAt(row, col);
                    try{
                        
                        Database Db=new Database();
                        Connection conn=Db.getConnected();
                        
                        String sql="Delete from seat where id="+id;
                        
                        Statement stmt=conn.createStatement();
                        
                        stmt.execute(sql);
                        JOptionPane.showMessageDialog(null,"Deleting Success..");
                        dispose();
                        SeatIndex IndexPage=new SeatIndex();
                        IndexPage.setVisible(true);
                        
                    }
                    
                    catch(Exception e1){
                        e1.printStackTrace();
                    }
                }
            
            
            });
            
            editMenu.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    int row=jTable1.getSelectedRow();
                    int col=0;
                    
                    int sid=(int) jTable1.getValueAt(row, col);
                    String old_no="";
                    String old_type="";
                    String old_price="";
                    String old_status="";
                    String old_theater_name="";
                    
                    try{
                        
                        Database Db=new Database();
                        Connection conn=Db.getConnected();
                        
                        String sql="Select * from seat WHERE id="+sid;
                        
                        Statement stmt=conn.createStatement();
                        ResultSet rs=stmt.executeQuery(sql);
                        
                        while(rs.next()){
                            old_no=rs.getString("no");
                            old_type=rs.getString("type");
                            old_price=rs.getString("price");
                            old_status=rs.getString("status");
                            old_theater_name=rs.getString("theater_name");
                            
                        }
                        
                    }
                    
                    catch(Exception e2){
                        e2.printStackTrace();
                    }
                    
                    JFrame editWindow=new JFrame();
                    
                    JButton close_btn=new JButton("[x]close");
                    close_btn.setBackground(orange);
                    editWindow.add(close_btn);
                    close_btn.setBounds(250,300,100,30);
                    
                    close_btn.addActionListener(new ActionListener(){
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            editWindow.setVisible(false);
                        }
                    
                    
                    });
                    
                    
                    JLabel no_label=new JLabel("Number");
                    no_label.setBounds(50,50,150,30);
                    editWindow.add(no_label);
                    
                    JTextField no_tf=new JTextField(old_no);
                    no_tf.setBounds(220,50,250,30);
                    editWindow.add(no_tf);
                    
                    JLabel type_lb=new JLabel("Type");
                    type_lb.setBounds(50,100,150,30);
                    editWindow.add(type_lb);
                    
                    JComboBox type_box=new JComboBox();
                    type_box.setBounds(220,100,250,30);
                    type_box.addItem("Single");
                    type_box.addItem("Couple");
                    type_box.addItem("VIP");
                    editWindow.add(type_box);
                    
                    JLabel price_lb=new JLabel("price");
                    price_lb.setBounds(50,150,150,30);
                    editWindow.add(price_lb);
                    
                    JTextField price_tf=new JTextField(old_price);
                    price_tf.setBounds(220,150,250,30);
                    editWindow.add(price_tf);
                    
                    JLabel status_lb=new JLabel("Status");
                    status_lb.setBounds(50,200,150,30);
                    editWindow.add(status_lb);
                    
                    JTextField status_tf=new JTextField(old_status);
                    status_tf.setBounds(220,200,250,30);
                    editWindow.add(status_tf);
                    
                    JLabel theater_name_lb=new JLabel("Theater Name");
                    theater_name_lb.setBounds(50,250,150,30);
                    editWindow.add(theater_name_lb);
                    
                    JTextField theater_name_tf=new JTextField(old_theater_name);
                    theater_name_tf.setBounds(220,250,250,30);
                    editWindow.add(theater_name_tf);
                    
                    editWindow.setDefaultCloseOperation(EXIT_ON_CLOSE);
                    editWindow.setLocationRelativeTo(null);
                    editWindow.setLayout(null);
                    editWindow.setSize(500,550);
                    editWindow.setVisible(true);
                    
                    
                    JButton upd_btn=new JButton("Update");
                    upd_btn.setBackground(green);
                    upd_btn.setBounds(365,300,100,30);
                    editWindow.add(upd_btn);
                    
                    
                    upd_btn.addActionListener(new ActionListener(){ 
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try{
                                
                                Database Db=new Database();
                                Connection conn=Db.getConnected();
                                
                                String sql="Update seat set no=?, type=?, price=?, status=?, theater_name=? WHERE id=?";
                                
                                PreparedStatement pst=conn.prepareStatement(sql);
                                
                                pst.setString(1, no_tf.getText());
                                pst.setString(2, type_box.getSelectedItem().toString());
                                pst.setString(3,price_tf.getText());
                                pst.setString(4, status_tf.getText());
                                pst.setString(5, theater_name_tf.getText());
                                pst.setInt(6, sid);
                                pst.execute();
                                
                                JOptionPane.showMessageDialog(null, "Editing Completed..");
                                editWindow.dispose();
                                
                                SeatIndex IndexPage=new SeatIndex();
                                IndexPage.setVisible(true);
                                
                                
                            }
                            
                            catch(Exception e3){
                                e3.printStackTrace();
                            }
                        }
                    
                    
                    });
                }
            
                
            });
            
            
        }
        
        catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "id", "No.", "Type", "Price", "Status", "Theater_Name"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setBackground(new java.awt.Color(255, 0, 0));
        jButton1.setForeground(new java.awt.Color(204, 255, 255));
        jButton1.setText("Create New Seat");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jButton1)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 726, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        CreateSeat createSeatWindow=new CreateSeat();
        createSeatWindow.setVisible(true);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
        AdminDashboard board=new AdminDashboard();
        board.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SeatIndex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SeatIndex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SeatIndex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SeatIndex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SeatIndex().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

    private void loadSeats() {
        
    }
}
